<?php

declare(strict_types=1);

namespace cooldogedev\BedrockDonateEconomy\api\exception;

use Exception;

final class RecordNotFoundException extends Exception {}